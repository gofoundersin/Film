(() => {
  const $ = id => document.getElementById(id);
  const grid = $('movieGrid');
  const movies = [];
  function addFiles(fileList) {
    [...fileList].filter(f => f.type.startsWith('video/') || /\.(mp4|webm|ogg|mov|m4v|mkv)$/i.test(f.name)).forEach(file => {
      const movie = { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random()), file, title: file.name.replace(/\.[^.]+$/, ''), size: file.size };
      movies.push(movie);
      if (movies.length === 1) window.NOIR_PLAYER.playFile(file, movie.title);
    });
    render();
  }
  function render() {
    $('filmCount').textContent = `${movies.length} ${movies.length === 1 ? 'film' : 'films'}`;
    const q = $('searchInput').value.toLowerCase().trim();
    const visible = movies.filter(m => m.title.toLowerCase().includes(q));
    grid.innerHTML = '';
    if (!visible.length) {
      grid.innerHTML = `<div class="library-empty"><span>✧</span><h3>${movies.length ? 'No matching films' : 'Your collection starts here'}</h3><p>${movies.length ? 'Try another title.' : 'Add video files from your device. They stay in this browser session.'}</p><label class="secondary-btn">＋ Add videos<input id="emptyGridUpload" type="file" accept="video/*,.mkv" multiple hidden></label></div>`;
      const input = $('emptyGridUpload'); if (input) input.addEventListener('change', e => addFiles(e.target.files));
      return;
    }
    visible.forEach((m, i) => {
      const card = document.createElement('article'); card.className = 'movie-card'; card.tabIndex = 0;
      const poster = document.createElement('div'); poster.className = 'movie-poster';
      const symbol = document.createElement('span'); symbol.textContent = '✦'; poster.appendChild(symbol);
      const info = document.createElement('div'); info.className = 'movie-info';
      const title = document.createElement('h3'); title.textContent = m.title;
      const meta = document.createElement('p'); meta.textContent = `${(m.size/1024/1024).toFixed(1)} MB · Local video`;
      const play = document.createElement('button'); play.textContent = '▶  Watch now';
      play.addEventListener('click', e => { e.stopPropagation(); window.NOIR_PLAYER.playFile(m.file, m.title); });
      info.append(title, meta, play); card.append(poster, info);
      card.addEventListener('click', () => window.NOIR_PLAYER.playFile(m.file, m.title));
      grid.appendChild(card);
    });
  }
  ['videoUpload','emptyUpload','gridUpload'].forEach(id => $(id).addEventListener('change', e => { addFiles(e.target.files); e.target.value = ''; }));
  $('heroPlay').addEventListener('click', () => {
    if (movies.length) window.NOIR_PLAYER.playFile(movies[0].file, movies[0].title);
    else $('videoUpload').click();
  });
  $('searchInput').addEventListener('input', render);
  render();
})();
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./service-worker.js').catch(() => {});
