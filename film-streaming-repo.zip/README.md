# NOIR — Personal Film Library

A responsive, GitHub Pages-ready personal video library with a custom HTML5 player.

## Features
- Add local video files from your device
- Play/pause, seek bar, volume and mute
- Brightness adjustment (visual filter)
- 10-second back/forward buttons
- Double-tap left/right side of the player to seek 10 seconds
- Playback speed, fullscreen and search
- Responsive dark cinematic layout
- Basic offline shell caching via service worker (requires HTTPS/localhost)

## Run locally
Open `index.html` in a modern browser. For service-worker/PWA behavior, use a local web server or GitHub Pages (HTTPS).

## Publish with GitHub Pages
1. Create a repository, for example `film-streaming`.
2. Upload all files and folders from this project.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. Open the published URL.

## Video compatibility
The browser's built-in HTML5 player supports common formats such as MP4 (H.264/AAC) and WebM, depending on browser codecs. MKV support is inconsistent on mobile browsers. If a file does not play, convert it to MP4 (H.264 video + AAC audio).

## Quality selector
The quality selector is prepared for multiple encoded versions, but this starter version has no adaptive streaming/transcoding backend. A single local file has only its encoded resolution. To offer real quality switching, add separate 360p/720p/1080p files or an HLS/DASH stream and connect those sources in `player.js`.

## Important storage note
Selected files are played directly from the device using temporary browser object URLs. They are not uploaded to GitHub or a server, and the library resets when the page is refreshed. This is a personal local-file player, not a public streaming/content-hosting service.

## Customize
- Change colors and layout in `style.css`.
- Add server-hosted film source URLs only for videos you own or are authorized to distribute.
- `data/movies.js` is reserved for future catalogue metadata.
