// Movie catalogue is populated by files selected in the browser.
window.NOIR_MOVIES = [];