(() => {
  const video = document.getElementById('video');
  const shell = document.getElementById('playerShell');
  const $ = id => document.getElementById(id);
  let tapTimer = null, lastTap = 0;
  const fmt = t => {
    if (!Number.isFinite(t)) return '00:00';
    const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = Math.floor(t % 60);
    return h ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  };
  function feedback(text) {
    $('centerFeedback').textContent = text;
    $('centerFeedback').classList.add('show');
    clearTimeout(feedback.timer);
    feedback.timer = setTimeout(() => $('centerFeedback').classList.remove('show'), 650);
  }
  function seek(delta) { if (video.src) { video.currentTime = Math.max(0, Math.min(video.duration || Infinity, video.currentTime + delta)); feedback(`${delta > 0 ? '+' : ''}${delta}s`); } }
  $('playPause').addEventListener('click', () => video.paused ? video.play() : video.pause());
  video.addEventListener('click', () => video.paused ? video.play() : video.pause());
  video.addEventListener('play', () => $('playPause').textContent = 'Ⅱ');
  video.addEventListener('pause', () => $('playPause').textContent = '▶');
  $('back10').addEventListener('click', () => seek(-10));
  $('forward10').addEventListener('click', () => seek(10));
  $('seekBar').addEventListener('input', e => { if (video.duration) video.currentTime = video.duration * e.target.value / 1000; });
  video.addEventListener('timeupdate', () => {
    $('currentTime').textContent = fmt(video.currentTime);
    $('duration').textContent = fmt(video.duration);
    if (video.duration) $('seekBar').value = video.currentTime / video.duration * 1000;
  });
  $('volume').addEventListener('input', e => { video.volume = Number(e.target.value); video.muted = false; $('muteBtn').textContent = video.volume === 0 ? '×' : '◖))'; });
  $('muteBtn').addEventListener('click', () => { video.muted = !video.muted; $('muteBtn').textContent = video.muted ? '×' : '◖))'; });
  $('speed').addEventListener('change', e => video.playbackRate = Number(e.target.value));
  $('brightnessBtn').addEventListener('click', () => $('brightnessPanel').classList.toggle('open'));
  $('brightness').addEventListener('input', e => { video.style.filter = `brightness(${e.target.value}%)`; $('brightnessValue').textContent = `${e.target.value}%`; });
  $('fullscreen').addEventListener('click', async () => {
    try { if (!document.fullscreenElement) await shell.requestFullscreen(); else await document.exitFullscreen(); } catch {}
  });
  $('quality').addEventListener('change', e => {
    const source = window.NOIR_ACTIVE_SOURCES || {};
    const selected = source[e.target.value];
    if (selected) { const time = video.currentTime, wasPlaying = !video.paused; video.src = selected; video.addEventListener('loadedmetadata', function restore(){ video.currentTime = time; if (wasPlaying) video.play(); }, {once:true}); }
  });
  function bindDoubleTap(el, direction) {
    el.addEventListener('touchend', e => {
      const now = Date.now();
      if (now - lastTap < 300) { e.preventDefault(); seek(direction * 10); lastTap = 0; }
      else lastTap = now;
    }, {passive:false});
    el.addEventListener('dblclick', e => { e.preventDefault(); seek(direction * 10); });
  }
  bindDoubleTap($('tapLeft'), -1); bindDoubleTap($('tapRight'), 1);
  $('closePlayer').addEventListener('click', () => { video.pause(); video.removeAttribute('src'); video.load(); $('emptyPlayer').hidden = false; });
  video.addEventListener('error', () => { if (video.currentSrc) $('videoStatus').textContent = 'This format may not be supported by your browser.'; });
  window.NOIR_PLAYER = {
    playFile(file, title) {
      const url = URL.createObjectURL(file);
      video.src = url; video.load(); $('emptyPlayer').hidden = true;
      $('nowTitle').textContent = title || file.name;
      $('videoStatus').textContent = 'Playing from this device';
      $('playerSection').scrollIntoView({behavior:'smooth', block:'start'});
      video.play().catch(() => {});
    },
    get video(){ return video; }
  };
})();